<?php
session_start();
include('verifica_login.php');
//print_r($_SESSION);exit;
// Tempo em segundos - 1 hora
ini_set('session.gc_maxlifetime', 3600);

// Tempo em segundos - 1 hora
session_set_cookie_params(3600);
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Buscar/cadastrar Produto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css"/>
	<script src="https://code.jquery.com/jquery-3.5.1.js"> </script>
	<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>  
	<script type="text/javascript" language="javascript">
		$(document).ready(function() {
    		$('#tabela').DataTable( {
        	"language": {
            	"url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
        }
    } );
} );

	</script>
</head>
<body>
	  
<div class="container"> <!-- container-fluid -->
	<div class="container">
		<div class="badge bg-primary text-wrap" style="width: 38rem; 
			padding: 20px; display: block; position: relative; top: 130px; color: #FFFFFF;
			background-color: #4982AF;
    		color: white;
    		border: 3px solid #034AA5; /* Azul */">	
  			Sistema Total Conforto - Cadastro e gerência de produtos
		</div>
		<nav class="navbar navbar-light bg-light">
  			<div class="container-fluid">
   			 <a class="navbar-brand" href="">
      		<img src="/img/logo1.png" alt="" width="250" height="250" class="d-inline-block align-text-top">
      	</a>
  </div>
</nav>	
		
<div class="centro">
		<br>
		<center><p>Busque pelo produto filtrando abaixo:</p></center><br><hr>
      <?php
      include 'dao/produtodao.class.php';
      include 'modelo/produto.class.php';

      if(isset($_POST['filtrar'])){

        $pesq = "";
        $pesq = $_POST['txtpesquisa']; //O que o user digitou
        $query = "";

        if($pesq != ""){

          $filtro = $_POST['rdfiltro']; //RadioButton

          if($filtro == 'codproduto'){
            $query = "where codproduto = ".$pesq;
          }else if($filtro == 'nome'){
            $query = "where nome like '%".$pesq."%'";
          }else if($filtro == 'tipo'){
            $query = "where tipo like '%".$pesq."%'";
		  }else if($filtro == 'descricao'){
            $query = "where descricao like '%".$pesq."%'";
          }else if($filtro == 'tensao'){
            $query = "where tensao like '%".$pesq."%'";
          }else if($filtro == 'fabricante'){
            $query = "where fabricante like '%".$pesq."%'";
          }else if($filtro == 'codModelo'){
            $query = "where codModelo like '%".$pesq."%'";
          }else if($filtro == 'codFabricante'){
            $query = "where codFabricante like '%".$pesq."%'";
          }else if($filtro == 'pecasReposicao'){
            $query = "where pecasReposicao like '%".$pesq."%'";
          }else if($filtro == 'quantidade'){
            $query = "where quantidade like '%".$pesq."%'";
		  }else if($filtro == 'localizacao'){
            $query = "where localizacao like '%".$pesq."%'";

          }else{
            $query = "";
          }
        }//fecha if isset rdfiltro

        $proDAO = new ProdutoDAO();
        $array = $proDAO->filtrar($query);

        unset($_POST['filtrar']);

      } else {

        $proDAO = new ProdutoDAO();
        $array = $proDAO->filtrarProduto();

      }//fecha else

      /* Testando se retornou dados */
      if(count($array) != 0) {
      ?>
      <!--<div id="dados" class="collapse" class="table" class="table-responsive">--> <!--Uso da classe collapse para ocultar e exibir dados-->
	  <div class="table" class="table-responsive">
        <table  id="tabela" class="display" style="width:100%" class="table table-striped table-bordered table-hover table-condensed">
          <thead>
            <tr>
              <th>ID</th>
			  <th>Nome</th>
              <th>Tipo</th>
              <th>Descrição</th>
			  <th>Tensão</th>
			  <th>Fabricante</th>
			  <th>Modelo</th>
			  <th>Cód. Fabricante</th>
              <th>Peças de Reposição</th>
              <th>Qtd.</th>
              <th>Local</th>	  
            </tr>
          </thead>

          <tfoot>
            <tr>
            
            </tr>
          </tfoot>

          
            <?php
            foreach($array as $a){
              echo "<tr>";
                echo "<td>$a->codProduto</td>";
				echo "<td>$a->nome</td>";
				echo "<td>$a->tipo</td>";
                echo "<td>$a->descricao</td>";
                echo "<td>$a->tensao</td>";
                echo "<td>$a->nomeFabricante</td>";
                echo "<td>$a->codModelo</td>";
				echo "<td>$a->codFabricante</td>";
				echo "<td>$a->pecasReposicao</td>";
                echo "<td>$a->quantidade</td>";
                echo "<td>$a->localizacao</td>";
              echo "</tr>";
            }//fecha foreach
            unset($array);
            ?>
         
        </table>
      </div><br> <!-- div tabela -->
      <?php
      } else {
        echo "<center><h2>Não há Produtos exibir!</h2></center><br>";
      }//fecha else
      ?><!--Fim do trecho de busca de dados-->
			<!--<div class="alert alert-danger" role="alert">
  					<center><p>Não há Produtos exibir!</p></center>
			</div>-->
      	
		<center><p>Esta página é somente para pesquisa de produtos. Caso queira editar ou cadastrar, use as opções abaixo.</p>
<!--Botões de ações da aplicação, chama a tela de edição ou sair-->
<hr>
		
   		<div class="card-top">
			<a href="cadastro-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Cadastrar </button></a>
			<a href="consultar-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Editar/Remover </button></a>
			<a href="logout.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Sair </button></a>
		</div>

<!--Rodapé da aplicação-->
		<hr></hr>
		<center><p>Total Conforto <?php echo date("Y"); ?> &reg</p><br> 
		</div>
    </div>
  </body>
</html>
