<?php session_start(); ob_start();?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	 
  </head>
  <body class="login">
<!--Corpo da aplicação-->
<div>
     
<!--Fomulário de autenticação de usuário-->
	<form class="form" action="login.php" method="POST">
		<div class="card">
			<div class="card-top">
				<img class="img-logo" src="/img/logo1.png">
				<center><h2>Realize o login:</h2>
<!--Mostra a mensagem ao usuário sobre usuário e senha incorretos-->
					<?php
						if(isset($_SESSION['nao_autenticado'])):
					?>
						<div class="alert alert-danger" role="alert"><!--Estoura o erro de usuário icorreto na tela-->
							<br><p>Erro: Usuário ou senha inválidos!</p>	
							<br><p>Tente novamente.</p>
						</div>
					<?php
						endif;
						unset($_SESSION['nao_autenticado']);
					?>
				<p></p>
			</div>
				
			<div class="card-group">
				<label>Email</label>
				<input type="text" name="usuario" placeholder="Digite o usuário" required>
			</div>
				
			<div class="card-group">
				<label>Senha</label>
				<input type="password" name="senha" placeholder="Digite a senha"required>
			</div>
				
			<div class="card-group">
				<label><input type="checkbox"> Lembre-me.</label>
			</div>
				
			<div class="card-group">
				<button type="submit"> Acessar </button>
			</div>
				<br><center><p>Total Conforto <?php echo date("Y"); ?> &reg</p>	
		</div>
	</form>		
			
<!--Rodapé da aplicação-->
	
		 
			
    </div>
  </body>
</html>
