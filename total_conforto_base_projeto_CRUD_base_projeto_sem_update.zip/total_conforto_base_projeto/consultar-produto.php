<?php
session_start();
include('verifica_login.php');
//print_r($_SESSION);exit;
// Tempo em segundos - 1 hora
ini_set('session.gc_maxlifetime', 3600);

// Tempo em segundos - 1 hora
session_set_cookie_params(3600);
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Editar/Remover Produto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css"/>
	<script src="https://code.jquery.com/jquery-3.5.1.js"> </script>
	<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>  
	<script type="text/javascript" language="javascript">
		$(document).ready(function() {
    		$('#tabela').DataTable( {
        	"language": {
            	"url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Portuguese-Brasil.json"
        }
    } );
} );

	</script>
 	
</head>
  <body>
    <div class="container"> <!-- container-fluid -->
		<div class="container">
			<div class="badge bg-primary text-wrap" style="width: 38rem; 
			padding: 20px; display: block; position: relative; top: 130px; color: #FFFFFF;
			background-color: #4982AF;
    		color: white;
    		border: 3px solid #034AA5; /* Azul */">	
  			Sistema Total Conforto - Cadastro e gerência de produtos
		</div>
		<nav class="navbar navbar-light bg-light">
  			<div class="container-fluid">
   			 <a class="navbar-brand" href="">
      		<img src="/img/logo1.png" alt="" width="250" height="250" class="d-inline-block align-text-top">
      	</a>
  </div>
</nav>
     
<div class="centro">
		<br><center><p>Use os dados dos produtos abaixo para editar ou remover "Tenha em mente a certeza sobre a ação, uma vez que é irreversível.":</p><hr></hr>

<!--Início da tabela de edição e remoção-->
	<br><?php
      include 'dao/produtodao.class.php';
      include 'modelo/produto.class.php';

      $proDAO = new ProdutoDAO();
      $array = $proDAO->filtrarProduto();


      if(count($array)!=0){
      ?>
      <div class="table" class="table-responsive">
		<table id="tabela" class="display" style="width:100%" class="table table-striped table-bordered table-hover table-condensed">
          <thead>
            <tr>
			  <th>Editar</th>
              <th>Excluir</th>
              <th>ID</th>
			  <th>Nome</th>
              <th>Tipo</th>
              <th>Descrição</th>
			  <th>Tensão</th>
			  <th>Fabricante</th>
			  <th>Modelo</th>
			  <th>Cód. Fabricante</th>
              <th>Peças de Reposição</th>
              <th>Qtd.</th>
              <th>Local</th>
            </tr>
          </thead>
          <tfoot>

          </tfoot>

          <tbody>
            <?php
            foreach($array as $a){
              echo "<tr>";
                echo "<td><A href='editar-produto.php?id=$a->codProduto'>Editar</a></td>";
                echo "<td><a href='consultar-produto.php?id=$a->codProduto'>Excluir</a></td>";
                echo "<td>$a->codProduto</td>";
				echo "<td>$a->nome</td>";
				echo "<td>$a->tipo</td>";
                echo "<td>$a->descricao</td>";
                echo "<td>$a->tensao</td>";
                echo "<td>$a->nomeFabricante</td>";
                echo "<td>$a->codModelo</td>";
				echo "<td>$a->codFabricante</td>";
				echo "<td>$a->pecasReposicao</td>";
                echo "<td>$a->quantidade</td>";
                echo "<td>$a->localizacao</td>";
              echo "</tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      <?php

      } else {
        echo "<h2>Não há Produtos há exibir!</h2><br>";

      }

      if(isset($_GET['id'])){
      

        $proDAO = new ProdutoDAO();
        $proDAO->deletarProduto($_GET['id']);
        header('location:consultar-produto.php');
        unset($_GET['id']);
      }
      ?><!--Fim do código do backend-->
		
	<br><center><p>Para acessar outras páginas, use as opções abaixo.</p>
	<hr>
	
<!--Botões de ações da aplicação, chama a tela de edição ou sair-->

		<div class="card-top">
			<a href="filtro-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Consultar </button></a>
			<a href="cadastro-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Cadastrar </button></a>
			<a href="logout.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Sair </button></a>
		</div>

<!--Rodapé da aplicação-->
		<hr></hr>
		<br><center><p>Total Conforto <?php echo date("Y"); ?> &reg</p>
	
    </div>
  </body>
</html>
