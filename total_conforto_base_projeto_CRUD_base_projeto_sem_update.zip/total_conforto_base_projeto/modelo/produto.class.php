<?php
class Produto {

  private $codProduto;
  private $nome;
  private $tipo;
  private $descricao;
  private $pecasReposicao;
  private $quantidade;
  private $localizacao;


  public function __construct(){}
  public function __destruct(){}

  public function __get($a){return $this->$a;}
  public function __set($a, $v){$this->$a = $v;}

  public function __toString(){
    return nl2br("Nome: $this->nome
                  tipo: $this->tipo
                  descricao: $this->descricao
                  pecasReposicao: $this->pecasReposicao
                  quantidade: $this->quantidade
                  localizacao: $this->localizacao");

  }
}
