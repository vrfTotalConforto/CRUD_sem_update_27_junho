<?php
class ConexaoBanco extends PDO {

  private static $instance = null;
      //nome do banco, usuario e senha
  public function __construct($dsn,$user,$pass){
      //Construtor da classe pai PDO
      parent::__construct($dsn,$user,$pass);
  }
  public static function getInstance(){
    if(!isset(self::$instance)){
      try{
        /* Cria e retorna uma nova conexão. */

        /*conforto é o nome do banco(database), deve ser igual no Mysql*/
        self::$instance = new ConexaoBanco("mysql:dbname=totalconforto_db;host=localhost","root","");
        /*
        "root","root", é onde tem a inserção da senha do banco local,
        "root","", podendo variar a posição,
        "","root", podendo variar a posição,
        se o banco local não tem senha, ou as posibilidade anteriores,
        não tiveram sucesso deixar em branco
        localhost","","");
        */
        /*
        para funcionar este, deve se fazer um banco local, chamado conforto,
        com todos os item presentes como:

        tabela com nome de produto
        idproduto,nome,tipo,descricao,capacidade,marca,similaridade,quantidade,localizacao
        ou
        Importar o banco Conforto_produto, com atenção para nomes
        estarem certos
        */

        /*
        Database: Conforto
        table: produto
        idproduto,nome,tipo,descricao,capacidade,marca,similaridade,quantidade,localizacao
        */


      }catch(PDOException $e){
        echo "Erro ao conectar! ".$e;
      }//fecha catch
    }//fecha if
    return self::$instance;
  }//fecha método
}//fecha classe
