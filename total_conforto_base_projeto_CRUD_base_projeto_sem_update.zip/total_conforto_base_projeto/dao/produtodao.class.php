<?php
require 'conexaobanco.class.php';
 class ProdutoDAO {

   private $conexao = null;

   public function __construct(){
     $this->conexao = ConexaoBanco::getInstance();
   }

   public function __destruct(){}
     /*
     Para alterar, adicionar, nome, tipo etc...
     deve se alterar, ou adicionar em:
     1- dao/Produtodao.class.php
     2- modelo/produto.class.php
     3- util/cadastro-produto.php
     4- util/consultar-produto.php
     5- util/editar-produto.php
     6- util/filtro-produto.php

     */

   //função cadastrar
   public function cadastrarProduto($pro){//objeto produto
     try {
       //SQL - CASE INSENSITIVE
       $stat = $this->conexao->prepare("insert into produto (nome,tipo,descricao,pecasReposicao,quantidade,localizacao)values(?,?,?,?,?,?)");
       $stat->bindValue(1,$pro->nome);
       $stat->bindValue(2,$pro->tipo);
       $stat->bindValue(3,$pro->descricao);
	   $stat->bindValue(4,$pro->pecasReposicao);
	   $stat->bindValue(5,$pro->quantidade);
       $stat->bindValue(6,$pro->localizacao);
       $stat->execute();
     }catch (PDOException $pe){
       echo "ERRO ao cadastrar Produto! Verifique os campos inseridos e tente novamente!" .$pe;
     }
   }//fecha cadastrarProduto
	 //Filtro de produtos
   public function filtrarProduto(){
     try {
       $stat = $this->conexao->query("select * from produto a 
		 LEFT JOIN modelo b on a.modelo_codModelo=b.codModelo
		 LEFT JOIN fabrica c on a.codProduto=c.produto_codProduto 
		 LEFT JOIN  fabricante d on d.codFabricante=c.fabricante_codFabricante");
       $array = $stat->fetchAll(PDO::FETCH_CLASS, 'Produto');
       return $array;
     }catch(PDOException $pe){
       echo "erro ao buscar Produtos!".$pe;
     }
   }
          //where titulo like '%a%'
   public function filtrar($query){  //função de Busca
     try {
       $stat = $this->conexao->query("select * from produto LEFT JOIN fabricante LEFT JOIN modelo ".$query);
       $array = $stat->fetchAll(PDO::FETCH_CLASS, 'Produto');
       return $array;
     } catch (PDOException $pe) {
       echo "Erro ao buscar!!".$pe;
     }
   }

//funcao deletar
   public function deletarProduto($id){
     try {
       $stat = $this->conexao->prepare("delete from produto where codProduto = ?");
       $stat->bindValue(1, $id);
       $stat->execute();
     } catch (PDOException $pe) {
       echo "Erro ao excluir!".$pe;
     }
   }

//funcão editar
   public function editarProduto($pro){
     try {
       $sql = "update produto set nome=?, tipo=?, descricao=?, pecasReposicao=?, quantidade=?, localizacao=? where codProduto =?";
      
     }catch(PDOException $pe){
       echo "Erro ao alterar produto! ".$pe;
     }
   }


   public function gerarJSON(){
     try {
       $stat = $this->conexao->query("select * from produto");
       return json_encode($stat->fetchAll(PDO::FETCH_ASSOC));
     } catch (PDOException $pe) {
       echo "Erro ao gerar JSON".$pe;
     }
   }
 }//fecha classe
