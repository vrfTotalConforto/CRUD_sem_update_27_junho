<?php
session_start();
include('verifica_login.php');
//print_r($_SESSION);exit;
// Tempo em segundos - 1 hora
ini_set('session.gc_maxlifetime', 3600);

// Tempo em segundos - 1 hora
session_set_cookie_params(3600);
ob_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <title>Editar produto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	 <link rel="stylesheet" type="text/css" href="estilo.css">
  </head>
  <body>
	  
<div class="container"> <!-- container-fluid -->
	<div class="container">
		<div class="badge bg-primary text-wrap" style="width: 38rem; 
			padding: 20px; display: block; position: relative; top: 130px; color: #FFFFFF;
			background-color: #4982AF;
    		color: white;
    		border: 3px solid #034AA5; /* Azul */">	
  			Sistema Total Conforto - Cadastro e gerência de produtos
		</div>
		<nav class="navbar navbar-light bg-light">
  			<div class="container-fluid">
   			 <a class="navbar-brand" href="">
      		<img src="/img/logo1.png" alt="" width="250" height="250" class="d-inline-block align-text-top">
      	</a>
  </div>
</nav>	 
	<?php
        include 'modelo/produto.class.php';
        include 'dao/produtodao.class.php';

        if (isset($_GET['id'])) {
          // echo "ID:".$_GET['id'];
          $proDAO = new ProdutoDAO();
          $query = "where codproduto=".$_GET['id'];
		  $array = $proDAO->filtrar($query);

          // var_dump($array);
          unset($_GET['id']);
        }
         ?>
<div class="centro">

		<center><p>Edite o as informações do produto abaixo:</p></center><hr>
        <form name="alterarproduto" method="post" action="">
          <div class="form-group">
            <input type="text" name="codproduto" placeholder="Código" class="form-control"
            readonly="readonly" value="<?php if(isset($array)) echo $array[0]->codProduto?>">
          </div>
          <div class="form-group">
            <input type="text" name="txtnome" placeholder="Nome do Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->nome?>">
          </div>
          <div class="form-group">
            <input type="text" name="txttipo" placeholder="Tipo de Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->tipo?>">
          </div>
          <div class="form-group">
            <input type="text" name="txtdescricao" placeholder="Descrição do Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->descricao?>">
          </div>
          <div class="form-group">
            <input type="text" name="txttensao" placeholder="Tensão do Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->tensao?>">
          </div>
          <div class="form-group">
            <input type="text" name="txtfabricante" placeholder="Fabricante do Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->fabricante?>">
          </div>
          <div class="form-group">
            <input type="text" name="txtmodelo" placeholder="Modelo" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->modelo?>">
          </div>
			<div class="form-group">
            <input type="text" name="txtcodigofabricante" placeholder="Código do Fabricante" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->codigofabricante?>">
          </div>
		  <div class="form-group">
            <input type="text" name="txtpecas" placeholder="Existe peças de reposição?" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->pecas?>">
          </div>
          <div class="form-group">
            <input type="number" name="txtquantidade" placeholder="Quantidade" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->quantidade?>">
          </div>
          <div class="form-group">
            <input type="text" name="txtlocalizacao" placeholder="Localização do Produto" class="form-control"
            value="<?php if(isset($array)) echo $array[0]->localizacao?>">
          </div>


          <div class="form-group">
            <input type="submit" name="cadastrar" value="Editar" class="btn btn-primary">
            <input type="reset" name="Limpar" value="Limpar" class="btn btn-danger">
          </div>
        </form><hr>

        <?php
        if(isset($_POST['cadastrar'])){
          include 'util/padronizacao.class.php';

          //padronizacao
		  $codProduto = Padronizacao::padronizarMaiMin($_POST['codproduto']);
          $nome = Padronizacao::padronizarMaiMin($_POST['txtnome']);
          $tipo = Padronizacao::padronizarMaiMin($_POST['txttipo']);
          $descricao = Padronizacao::padronizarMaiMin($_POST['txtdescricao']);
          $pecasReposicao = Padronizacao::padronizarMaiMin($_POST['txtpecas']);
          $quantidade = Padronizacao::padronizarMaiMin($_POST['txtquantidade']);
          $localizacao = Padronizacao::padronizarMaiMin($_POST['txtlocalizacao']);



          //validacao
          $pro = new Produto();
		  $pro->codProduto = $codProduto;
          $pro->nome = $nome;
          $pro->tipo = $tipo;
          $pro->descricao = $descricao;
		  $pro->pecasreposicao = $pecasReposicao;
          $pro->quantidade = $quantidade;
          $pro->localizacao = $localizacao;
			//echo ("<pre>");
			//var_dump($pro);
            //echo ("</pre>");
			
			//exit();
          //banco
          $proDAO = new ProdutoDAO();
          $proDAO->editarProduto($pro);
          header("location:consultar-produto.php");
        }//fecha if
        ?><!--Termino do código backend-->

<!--Botões de ações da aplicação, chama a tela de edição ou sair-->

		
		<div class="card-top">
			<a href="filtro-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Buscar Produto </button></a>
			<a href="consultar-produto.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Editar Produto </button></a>
			<a href="logout.php"><button style="background: #2A6DC2 /*#069cc2*/; border-radius: 6px; padding: 12px; cursor: pointer; color: #fff; border: none; font-size: 14px; text-align: center;"> Sair </button></a>
		</div>
	
<!--Rodapé da aplicação-->
			<hr></hr>
			<center><p>Total Conforto <?php echo date("Y"); ?> &reg</p><br> 
		</div>	
      </div>
  </body>
</html>
