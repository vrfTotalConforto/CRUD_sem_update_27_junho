<?php 
session_start();
if(!$_SESSION['usuario']) {
	header('Location: admin.php');
	exit();
}

if (!isset($_SESSION['MINHA_SESSAO'])) {
    $_SESSION['MINHA_SESSAO'] = time();
} else if (time() - $_SESSION['MINHA_SESSAO'] > 1800) { // sessão iniciada há mais de 30 minutos
    session_regenerate_id(true); // muda o ID da sessão para o ID corrente e invalidar o ID antigo
    $_SESSION['MINHA_SESSAO'] = time();  // atualiza o tempo de criação da sessão
}

?>